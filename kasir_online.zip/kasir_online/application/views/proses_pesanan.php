<div class="container-fluid">
    <div class="alert alert-success">
        <p class="text-center align-middle"text-center >Selamat, Pesanan Anda Telah Berhasil diproses</p><br><br>
        <p class="text-center align-middle"text-center >Silahkan Tunggu Di Tempat Yang Sudah Di Sediakan</p>
    </div>
</div>

